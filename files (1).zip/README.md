# Data Redundancy Removal System

A professional **Streamlit** web application for detecting and removing duplicate
records from CSV files, with a full-featured **SQLite**-backed database for
manual data management, validation, search, and analytics.

Built as a Cloud Computing internship project.

---

## Features

| Feature | Description |
|---|---|
| 📁 CSV Upload | Upload any CSV file for processing |
| 🔎 Duplicate Detection | Detect duplicate rows based on user-selected column(s) |
| 🧹 Remove Duplicates | Remove duplicates while keeping first or last occurrence |
| ⬇️ Download Cleaned CSV | Export the deduplicated dataset as a new CSV file |
| 🗄️ SQLite Database | Persistent local database (`database.db`) storing all records |
| ✍️ Manual Data Entry | Add new records directly through a validated web form |
| ✅ Email Validation | Regex-based email format validation |
| ✅ Phone Validation | Regex-based phone number format validation |
| 🚫 Duplicate Email Prevention | Database-level `UNIQUE` constraint + application checks stop duplicate emails |
| 🔍 Search | Search records by **ID**, **Name**, or **Email** |
| ✏️ Update Record | Edit any existing record with re-validation |
| 🗑️ Delete Record | Remove a record after confirmation |
| 📊 Dashboard | Live statistics: total records, duplicate emails/names, growth chart |
| 📤 Export Database | Export the entire database table to CSV at any time |
| 🎨 Professional UI | Clean sidebar navigation, styled stat cards, responsive layout |

---

## Project Structure

```
data-redundancy-removal-system/
├── app.py              # Main Streamlit application (all logic)
├── requirements.txt    # Python dependencies
├── sample_data.csv     # Sample CSV with intentional duplicates for testing
├── README.md           # Project documentation (this file)
└── database.db         # SQLite database (auto-created on first run)
```

---

## Requirements

- Python 3.9+
- pip

Dependencies (see `requirements.txt`):
- `streamlit`
- `pandas`

---

## Installation & Setup

1. **Clone or download** this project folder.

2. **(Recommended) Create a virtual environment**
   ```bash
   python -m venv venv
   source venv/bin/activate      # On Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run the application**
   ```bash
   streamlit run app.py
   ```

5. Streamlit will open the app automatically in your browser at
   `http://localhost:8501`. The SQLite database file (`database.db`) is
   created automatically in the same folder on first run.

---

## How to Use

### 1. Dashboard
View total records, duplicate email/name counts, a records-over-time chart,
and the full current database table.

### 2. Upload & Clean CSV
- Upload a CSV (try the included `sample_data.csv`, which has intentional duplicates).
- Choose which column(s) define a "duplicate" (e.g. `email`).
- Choose whether to keep the first or last occurrence.
- Click **Remove Duplicates** to generate the cleaned dataset.
- Download the cleaned CSV, or import it straight into the SQLite database
  (rows with invalid or already-existing emails are automatically skipped).

### 3. Manual Data Entry
Add a new record via a form. Name, email, and phone are all validated:
- Email must match a standard `name@domain.tld` pattern.
- Phone must be 7–15 digits, optionally prefixed with `+`.
- Duplicate emails are rejected both by application logic and a database
  `UNIQUE` constraint.

### 4. Search Records
Search the database by **ID**, **Name** (partial match), or **Email**
(partial match).

### 5. Update / Delete Record
Look up a record by ID, edit its fields (re-validated on save), or delete it
after an explicit confirmation checkbox.

### 6. Export Database
Download the entire database table as a timestamped CSV file at any time.

---

## Validation Rules

**Email:**
```
^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$
```

**Phone:**
```
^\+?[0-9]{7,15}$
```
(spaces, hyphens, and parentheses are stripped before validation)

---

## Database Schema

```sql
CREATE TABLE records (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL,
    email       TEXT NOT NULL UNIQUE,
    phone       TEXT,
    created_at  TEXT
);
```

The `UNIQUE` constraint on `email` guarantees duplicate-email prevention at
the database layer, in addition to the application-level checks.

---

## Notes

- The SQLite database file `database.db` is created automatically the first
  time the app runs and persists between sessions.
- To reset the database, simply delete `database.db` and restart the app.
- All CSV column names are normalized to lowercase for consistent processing.

---

## Tech Stack

- **Frontend / App Framework:** Streamlit
- **Data Processing:** Pandas
- **Database:** SQLite3 (built into Python standard library)
- **Language:** Python 3

---

## Author

Cloud Computing Internship Project — Data Redundancy Removal System.
